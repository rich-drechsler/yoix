sub peer_cleanuser {
    my $user = $_[0];

    return(1);
}

return 1;
